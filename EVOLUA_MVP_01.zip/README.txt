EVOLUA — MVP 0.1
=================

Primeira versão de teste para acompanhar o Theo.

O MVP inclui:
- Home do pai
- Perfil do Theo
- Registro de treino
- Avaliação rápida por estrelas
- Observação/digitação por voz (quando suportado pelo navegador)
- Histórico de treinos
- Indicadores por área
- Gráfico de evolução
- Dados salvos localmente no aparelho

COMO TESTAR
1. Abra o arquivo index.html no navegador do computador para uma prévia.
2. Para instalar como "app" no celular, o ideal é publicar esta pasta em um endereço HTTPS.
3. No Android: abra no Chrome e use "Adicionar à tela inicial".
4. No iPhone: abra no Safari e use Compartilhar > Adicionar à Tela de Início.

OBSERVAÇÃO
Esta é uma versão de teste local. Os dados ficam no armazenamento do navegador do aparelho e não são enviados para servidor.
A próxima versão pode ter login, sincronização, fotos/vídeos, avaliação inicial, relatório mensal e IA real.
